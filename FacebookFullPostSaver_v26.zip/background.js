/**
 * Facebook Full Post Saver — background.js v26
 *
 * Handles messages from content.js:
 *   { action: 'ping' }      → keepalive, responds immediately
 *   { action: 'saveMHTML' } → capture page as .mht and download
 *
 * MV3 FIX: chrome.pageCapture.saveAsMHTML returns ArrayBuffer in MV3,
 * NOT a Blob. Must wrap in new Blob([arrayBuffer]) before createObjectURL.
 */

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || !tab.url.includes('facebook.com')) return;
  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['panel.css'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (err) {
    console.error('[FB Post Saver] Injection failed:', err);
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'ping') {
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'saveMHTML') {
    const tabId = sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ error: 'No tab id' });
      return false;
    }

    chrome.pageCapture.saveAsMHTML({ tabId }, (mhtmlData) => {
      if (chrome.runtime.lastError || !mhtmlData) {
        sendResponse({
          error: (chrome.runtime.lastError || {}).message || 'pageCapture returned empty data'
        });
        return;
      }

      // MV3: saveAsMHTML returns ArrayBuffer — must wrap in Blob first
      const blob = new Blob([mhtmlData], { type: 'multipart/related' });
      const url  = URL.createObjectURL(blob);
      const ts   = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');

      chrome.downloads.download(
        { url, filename: 'facebook_post_' + ts + '.mht', saveAs: false },
        (downloadId) => {
          // Revoke after 15s to ensure download has started
          setTimeout(() => URL.revokeObjectURL(url), 15000);
          if (chrome.runtime.lastError) {
            sendResponse({ error: (chrome.runtime.lastError || {}).message });
          } else {
            sendResponse({ ok: true, downloadId });
          }
        }
      );
    });

    return true; // keep message channel open for async response
  }
});
