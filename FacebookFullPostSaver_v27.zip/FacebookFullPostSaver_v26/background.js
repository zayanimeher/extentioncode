/**
 * Facebook Full Post Saver — background.js v27
 *
 * Handles messages from content.js:
 *   { action: 'ping' }      → keepalive, responds immediately
 *   { action: 'saveMHTML' } → capture page as .mht and download
 *
 * MV3 FIX: URL.createObjectURL() is NOT available in MV3 service workers.
 * Solution: convert the ArrayBuffer to a base64 data URL instead,
 * which chrome.downloads.download() accepts without needing a blob URL.
 */

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.url || !tab.url.includes('facebook.com')) return;
  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ['panel.css'] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['content.js'] });
  } catch (err) {
    console.error('[FB Post Saver] Injection failed:', err);
  }
});

/** Convert an ArrayBuffer to a base64 data URL (works in MV3 service workers) */
function arrayBufferToDataURL(buffer, mimeType) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return 'data:' + mimeType + ';base64,' + btoa(binary);
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'ping') {
    sendResponse({ ok: true });
    return false;
  }

  if (msg.action === 'saveMHTML') {
    const tabId = sender.tab && sender.tab.id;
    if (!tabId) {
      sendResponse({ error: 'No tab id' });
      return false;
    }

    chrome.pageCapture.saveAsMHTML({ tabId }, (mhtmlData) => {
      if (chrome.runtime.lastError || !mhtmlData) {
        sendResponse({
          error: (chrome.runtime.lastError || {}).message || 'pageCapture returned empty data'
        });
        return;
      }

      // MV3: URL.createObjectURL() does NOT work in service workers.
      // Convert ArrayBuffer → base64 data URL, which chrome.downloads accepts.
      let dataUrl;
      try {
        dataUrl = arrayBufferToDataURL(mhtmlData, 'multipart/related');
      } catch (e) {
        sendResponse({ error: 'base64 conversion failed: ' + e.message });
        return;
      }

      const ts = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');

      chrome.downloads.download(
        { url: dataUrl, filename: 'facebook_post_' + ts + '.mht', saveAs: false },
        (downloadId) => {
          if (chrome.runtime.lastError) {
            sendResponse({ error: (chrome.runtime.lastError || {}).message });
          } else {
            sendResponse({ ok: true, downloadId });
          }
        }
      );
    });

    return true; // keep message channel open for async response
  }
});
