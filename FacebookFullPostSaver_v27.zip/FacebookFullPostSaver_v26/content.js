/**
 * Facebook Full Post Saver — content.js v21
 *
 * IMPROVEMENTS vs v20:
 *  1. Smart early-exit: exits as soon as scrollHeight stops growing
 *     (2 identical readings) instead of waiting all STABLE_ROUNDS × BOTTOM_EXTRA_MS.
 *  2. Fingerprint bucket 40px → 80px: prevents double-clicks after minor
 *     FB re-renders that shift button positions by ~20-40px.
 *  3. Adaptive settle floor: tracks recent settle durations and adjusts
 *     the minimum wait floor accordingly (fast conn=400ms, slow=up to 2000ms).
 *  4. Removed unused isReplyBtn function.
 *  5. Save: MHTML (.mht) via chrome.pageCapture first, HTML fallback if it fails.
 *     Panel hidden before MHTML capture, restored after. 60s timeout.
 *  6. No-scroll full-page click: fullPageScan uses el.click() directly,
 *     no scrollIntoView() jarring jumps.
 */
(function () {
  'use strict';

  if (window.__fbpsSaverLoaded) {
    const p = document.getElementById('fbps-panel');
    if (p) p.style.display = (p.style.display === 'none') ? '' : 'none';
    return;
  }
  window.__fbpsSaverLoaded = true;

  const CFG = {
    MAX_RUNTIME_MS:   15 * 60 * 1000,
    SCROLL_STEP_PX:   400,
    DWELL_MS:         350,
    SETTLE_QUIET_MS:  400,
    SETTLE_MIN_MS:    400,   // base floor — adapted dynamically
    SETTLE_MAX_MS:    5000,
    STABLE_ROUNDS:    6,
    BOTTOM_EXTRA_MS:  4000,
    MAX_CLICKS:       8000,
  };

  const TARGETS = [
    'en voir plus',
    'voir plus de commentaires',
    'voir les réponses',
    'voir plus de réponses',
    'réponse',
    'afficher les réponses',
    'réponses',
    'a répondu',
  ];

  const DENY_NORM = new Set([
    'répondre','réagir',"j'aime",'like','share','send',
    'laissez un commentaire','envoyez ce contenu à vos ami(e)s ou publiez-le sur votre profil.',
    'masquer ou signaler un abus cela','voix disponibles',
    'commentez avec un sticker avatar','insérez un emoji',
    'commentez avec un gif','commentez avec un sticker',
    'post comment','facebook menu','messenger','notifications',
    'votre profil','photo précédente','photo suivante',
    'zoom','dézoom','passer en plein écran',
    'retour à la page précédente','quitter la saisie semi-automatique',
    'actions pour cette publication',
    'follow','report','hide','delete','edit','save','bookmark','copy link',
  ]);

  const S = {
    running: false, cancelled: false,
    clickedFps: new Set(),
    nClicks: 0, t0: 0, log: [],
    scroller: null,
    scrollerMinH: 0,
    settleTimes: [],   // history of recent settle durations for adaptive floor
  };

  /* ── PANEL ─────────────────────────────────────────────────────────── */
  function buildPanel() {
    const el = document.createElement('div'); el.id = 'fbps-panel';
    el.innerHTML = [
      '<div id="fbps-hdr"><div id="fbps-title"><span>💾</span> Post Saver</div><button id="fbps-min">−</button></div>',
      '<div id="fbps-body">',
      '<button id="fbps-btn-save"><span id="fbps-btn-ico">📥</span><span id="fbps-btn-lbl"> Save Full Post</span></button>',
      '<button id="fbps-btn-diag">🔍 Scan (debug)</button>',
      '<button id="fbps-btn-cancel" class="fbps-hide">✕ Annuler</button>',
      '<div id="fbps-prog-wrap" class="fbps-hide"><div id="fbps-prog-track"><div id="fbps-prog-bar"></div></div></div>',
      '<div id="fbps-status-row"><div id="fbps-dot"></div><div id="fbps-msg">Idle</div></div>',
      '<div id="fbps-stats" class="fbps-hide">',
      '<div class="fbs"><div class="fbv" id="fbps-nc">0</div><div class="fbl">Clics</div></div>',
      '<div class="fbs"><div class="fbv" id="fbps-nt">0s</div><div class="fbl">Temps</div></div>',
      '</div>',
      '<div id="fbps-logwrap" class="fbps-hide"><div id="fbps-log"></div></div>',
      '<button id="fbps-btn-copy" class="fbps-hide">📋 Copier log</button>',
      '<div id="fbps-done" class="fbps-hide">✅ Sauvegardé !</div>',
      '</div>',
    ].join('');
    document.body.appendChild(el);
    drag(el, g('fbps-hdr'));
    g('fbps-btn-save').onclick   = startSave;
    g('fbps-btn-diag').onclick   = runDiag;
    g('fbps-btn-cancel').onclick = () => { S.cancelled = true; status('Annulé', 'err'); };
    g('fbps-min').onclick = () => { const m = el.classList.toggle('fbps-mini'); g('fbps-min').textContent = m ? '+' : '−'; };
    g('fbps-btn-copy').onclick = copyLog;
  }

  function drag(panel, handle) {
    let ox, oy, sx, sy;
    handle.onmousedown = e => {
      e.preventDefault();
      const r = panel.getBoundingClientRect(); ox = r.left; oy = r.top; sx = e.clientX; sy = e.clientY;
      document.body.style.userSelect = 'none';
      document.onmousemove = e => { panel.style.right = 'auto'; panel.style.left = (ox + e.clientX - sx) + 'px'; panel.style.top = (oy + e.clientY - sy) + 'px'; };
      document.onmouseup  = () => { document.onmousemove = null; document.onmouseup = null; document.body.style.userSelect = ''; };
    };
  }

  const g     = id => document.getElementById(id);
  const show  = id => { const e = g(id); if (e) e.classList.remove('fbps-hide'); };
  const hide  = id => { const e = g(id); if (e) e.classList.add('fbps-hide'); };
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  function status(msg, type) {
    const dot = g('fbps-dot'), txt = g('fbps-msg');
    if (dot) dot.className = type || '';
    if (txt) txt.textContent = msg;
    log(msg, type === 'ok' ? 'ok' : type === 'err' ? 'err' : type === 'warn' ? 'warn' : 'inf');
  }
  function prog(pct) { const bar = g('fbps-prog-bar'); if (!bar) return; show('fbps-prog-wrap'); bar.classList.remove('ind'); bar.style.width = Math.min(100, pct) + '%'; }
  function log(msg, cls) {
    const el = g('fbps-log'); if (!el) return; show('fbps-logwrap');
    const e = document.createElement('div');
    const t = S.t0 ? '+' + Math.round((Date.now() - S.t0) / 1000) + 's' : '+0s';
    e.className = 'fbl-' + (cls || 'inf'); e.textContent = t + ' ' + msg;
    el.appendChild(e); el.scrollTop = el.scrollHeight;
    S.log.push(t + ' ' + msg);
    while (el.children.length > 500) el.removeChild(el.firstChild);
  }
  function tick() {
    const nc = g('fbps-nc'), nt = g('fbps-nt'); if (!nc) return;
    nc.textContent = S.nClicks;
    nt.textContent = Math.round((Date.now() - S.t0) / 1000) + 's';
  }
  function copyLog() {
    const txt = S.log.join('\n');
    navigator.clipboard.writeText(txt)
      .then(() => { g('fbps-btn-copy').textContent = '✅ Copié !'; setTimeout(() => g('fbps-btn-copy').textContent = '📋 Copier log', 2500); })
      .catch(() => { const ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:2147483647;width:500px;height:280px;font:11px monospace;background:#111;color:#eee;border:1px solid #555;border-radius:8px;padding:10px'; document.body.appendChild(ta); ta.select(); alert('Ctrl+C pour copier'); ta.addEventListener('blur', () => setTimeout(() => ta.remove(), 200)); });
  }

  /* ══════════════════════════════════════════════════════════════════
     ADAPTIVE SETTLE — waitForDOMSettle() with dynamic floor
     Tracks the last 3 actual settle durations and sets the minimum
     wait floor to 120% of their average, clamped 400ms–2000ms.
  ══════════════════════════════════════════════════════════════════ */
  function adaptiveFloor() {
    const BASE = 400, MAX = 2000;
    if (S.settleTimes.length === 0) return BASE;
    const recent = S.settleTimes.slice(-3);
    const avg = recent.reduce((a, b) => a + b, 0) / recent.length;
    return Math.min(MAX, Math.max(BASE, Math.round(avg * 1.2)));
  }

  function waitForDOMSettle() {
    return new Promise(resolve => {
      const root    = S.scroller || document.body;
      const start   = Date.now();
      const floor   = adaptiveFloor();
      let quietTimer = null;
      let settled   = false;

      function done() {
        if (settled) return;
        settled = true;
        observer.disconnect();
        const duration = Date.now() - start;
        S.settleTimes.push(duration);
        if (S.settleTimes.length > 10) S.settleTimes.shift();
        resolve();
      }
      function resetQuiet() {
        if (quietTimer) clearTimeout(quietTimer);
        quietTimer = setTimeout(() => {
          const elapsed = Date.now() - start;
          const rem = floor - elapsed;
          if (rem > 0) setTimeout(done, rem); else done();
        }, CFG.SETTLE_QUIET_MS);
      }

      const observer = new MutationObserver(resetQuiet);
      observer.observe(root, { childList: true, subtree: true });
      resetQuiet();
      setTimeout(done, CFG.SETTLE_MAX_MS);
    });
  }

  /* ── SCROLLER ──────────────────────────────────────────────────────── */
  const MODAL_SELECTORS = [
    'div[role="dialog"]',
    'div[data-pagelet="MediaViewerPhoto"]',
    'div[data-pagelet="permalink_reaction_dialog"]',
  ];

  function findScrollerInside(root) {
    let best = null, bestH = 0;
    root.querySelectorAll('*').forEach(el => {
      try {
        const ov = window.getComputedStyle(el).overflowY;
        if (ov !== 'auto' && ov !== 'scroll') return;
        if (el.scrollHeight <= el.clientHeight + 10) return;
        const b = el.scrollTop; el.scrollTop = b + 1;
        const moved = el.scrollTop !== b; el.scrollTop = b;
        if (moved && el.scrollHeight > bestH) { best = el; bestH = el.scrollHeight; }
      } catch (_) {}
    });
    return best;
  }

  function findModalScroller() {
    for (const sel of MODAL_SELECTORS) {
      for (const dialog of document.querySelectorAll(sel)) {
        const sc = findScrollerInside(dialog);
        if (sc) return sc;
      }
    }
    return null;
  }

  function findAnyScroller() {
    let best = null, bestH = 0;
    document.querySelectorAll('*').forEach(el => {
      if (el === document.body || el === document.documentElement) return;
      try {
        const ov = window.getComputedStyle(el).overflowY;
        if (ov !== 'auto' && ov !== 'scroll') return;
        if (el.scrollHeight <= el.clientHeight + 10) return;
        const b = el.scrollTop; el.scrollTop = b + 1;
        const moved = el.scrollTop !== b; el.scrollTop = b;
        if (moved && el.scrollHeight > bestH) { best = el; bestH = el.scrollHeight; }
      } catch (_) {}
    });
    return best;
  }

  async function waitForModalScroller(maxMs) {
    const deadline = Date.now() + maxMs;
    while (Date.now() < deadline) {
      const sc = findModalScroller();
      if (sc) return sc;
      await sleep(300);
    }
    return null;
  }

  function ensureScroller() {
    if (S.scroller && document.contains(S.scroller)) return;
    if (S.scroller) log('Scroller déconnecté — re-détection…', 'warn');
    const candidate = findModalScroller() || findAnyScroller();
    if (candidate && candidate.scrollHeight >= S.scrollerMinH * 0.8) {
      S.scroller = candidate;
      log('Scroller: scrollH=' + S.scroller.scrollHeight, 'ok');
    } else {
      log('Pas de scroller acceptable — scroll window', 'warn');
      S.scroller = null;
    }
  }

  function scrollTop()    { return S.scroller ? S.scroller.scrollTop    : window.scrollY; }
  function scrollHeight() { return S.scroller ? S.scroller.scrollHeight : document.documentElement.scrollHeight; }
  function clientHeight() { return S.scroller ? S.scroller.clientHeight : window.innerHeight; }
  function scrollBy(px)   { if (S.scroller) S.scroller.scrollTop += px; else window.scrollBy(0, px); }
  function scrollTo(y)    { if (S.scroller) S.scroller.scrollTop = y;   else window.scrollTo(0, y); }

  /* ── FINGERPRINT v3 — 80px bucket ─────────────────────────────────── */
  function fingerprint(el) {
    const text = norm(
      el.getAttribute('aria-label') ||
      (el.innerText || el.textContent || '').slice(0, 80)
    );
    let anc = el.parentElement, ancId = '';
    for (let i = 0; i < 12 && anc; i++, anc = anc.parentElement) {
      const id = anc.getAttribute('data-testid') ||
                 anc.getAttribute('id') ||
                 anc.getAttribute('aria-labelledby') || '';
      if (id) { ancId = id.slice(0, 40); break; }
    }
    let bucketY = 0;
    try {
      const r  = el.getBoundingClientRect();
      const sr = S.scroller ? S.scroller.getBoundingClientRect() : { top: 0 };
      const absY = (S.scroller ? S.scroller.scrollTop : window.scrollY) + r.top - sr.top;
      bucketY = Math.round(absY / 80); // 80px bucket (was 40px)
    } catch (_) {}
    return `${text}||${ancId}||y${bucketY}`;
  }

  /* ── MATCHING ──────────────────────────────────────────────────────── */
  function norm(s) { return (s || '').replace(/\s+/g, ' ').trim().toLowerCase(); }

  function matchesTarget(label) {
    const n = norm(label);
    return TARGETS.some(t => n.includes(t));
  }

  function isDenied(label) {
    const n = norm(label);
    if (DENY_NORM.has(n)) return true;
    if (/\d[\d\s]*(k|personne|people|réaction)/i.test(n)) return true;
    if (/toutes.*réactions/i.test(n)) return true;
    if (/^\d+$/.test(n)) return true;
    if (/voir qui a réagi/i.test(n)) return true;
    if (/afficher/i.test(n) && !/réponse|comment/i.test(n)) return true;
    if (/:\s*\d/.test(n)) return true;
    return false;
  }

  function isInView(el) {
    try {
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) return false;
      if (!S.scroller) return r.top < window.innerHeight && r.bottom > 0;
      const sr = S.scroller.getBoundingClientRect();
      return r.top < sr.bottom && r.bottom > sr.top && r.left < sr.right && r.right > sr.left;
    } catch (_) { return false; }
  }

  /* ── DIAGNOSTIC ────────────────────────────────────────────────────── */
  function runDiag() {
    g('fbps-log') && (g('fbps-log').innerHTML = '');
    S.log = []; S.t0 = Date.now(); show('fbps-logwrap'); show('fbps-btn-copy');
    const sc = findModalScroller() || findAnyScroller();
    log('Scroller: ' + (sc ? sc.tagName + ' scrollH=' + sc.scrollHeight + ' clientH=' + sc.clientHeight : 'window'));
    const root = sc || document;
    const els = root.querySelectorAll('div[role="button"],span[role="button"],a[role="button"],button');
    const seen = new Set(); let found = 0, denied = 0;
    for (const el of els) {
      const label = (el.getAttribute('aria-label') || el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120);
      const n = norm(label); if (!n || seen.has(n)) continue; seen.add(n);
      if (matchesTarget(label) && !isDenied(label)) { log('✅ "' + label + '"', 'ok'); found++; }
      else if (matchesTarget(label)) { log('🚫 "' + label + '"', 'warn'); denied++; }
    }
    log('─── Clickables: ' + found + ' | Bloqués: ' + denied + ' ───', found > 0 ? 'ok' : 'warn');
  }

  /* ── ENTRY POINT ───────────────────────────────────────────────────── */
  async function startSave() {
    if (S.running) return;
    S.running = true; S.cancelled = false;
    S.nClicks = 0; S.log = []; S.t0 = Date.now();
    S.clickedFps = new Set();
    S.scroller = null; S.scrollerMinH = 0;
    S.settleTimes = [];
    hide('fbps-done'); g('fbps-log').innerHTML = '';
    show('fbps-stats'); show('fbps-logwrap'); show('fbps-btn-copy');
    g('fbps-btn-save').disabled = true; g('fbps-btn-save').classList.add('fbps-running');
    g('fbps-btn-lbl').textContent = ' En cours…'; show('fbps-btn-cancel');
    const ticker = setInterval(tick, 500);
    try { await pipeline(); }
    catch (err) { if (!S.cancelled) { status('Erreur: ' + (err && err.message ? err.message : err), 'err'); if (err && err.stack) log(err.stack, 'err'); } }
    finally {
      clearInterval(ticker); tick();
      S.running = false; g('fbps-btn-save').disabled = false;
      g('fbps-btn-save').classList.remove('fbps-running');
      g('fbps-btn-ico').textContent = '📥'; g('fbps-btn-lbl').textContent = ' Save Full Post';
      hide('fbps-btn-cancel');
    }
  }

  async function pipeline() {
    status('Recherche du scroller…'); prog(3);
    log('Tentative scroller modal (3s)…');
    let sc = await waitForModalScroller(3000);
    if (sc) {
      log('Scroller modal: scrollH=' + sc.scrollHeight + ' clientH=' + sc.clientHeight, 'ok');
    } else {
      sc = findAnyScroller();
      if (sc) log('Scroller direct: scrollH=' + sc.scrollHeight + ' clientH=' + sc.clientHeight, 'ok');
      else     log('Utilisation de window', 'warn');
    }
    S.scroller = sc;
    S.scrollerMinH = sc ? sc.scrollHeight : 0;

    status('Retour en haut…'); prog(5);
    scrollTo(0); await sleep(500);
    if (S.cancelled) return;

    status('Sélection "Tous les commentaires"…'); prog(7);
    await ensureAllCommentsFilter();
    if (S.cancelled) return;

    status('Expansion des commentaires…'); prog(8);
    await expandLoop();
    if (S.cancelled) return;

    status('Sauvegarde…'); prog(90);
    await savePage();
    status('Terminé !', 'ok'); prog(100);
    g('fbps-dot').className = 'ok'; show('fbps-done');
  }

  /* ══════════════════════════════════════════════════════════════════
     ENSURE ALL COMMENTS FILTER
     Detects the comment sort button, opens the menu (rendered as a
     body-level portal by FB), selects "Tous les commentaires", and
     waits for the comment list to reload via waitForDOMSettle().
     Falls back to "Les plus récents" if the primary option is missing.
     Retries the full sequence up to 3 times.
  ══════════════════════════════════════════════════════════════════ */
  async function ensureAllCommentsFilter() {
    const TARGET_LABEL   = 'tous les commentaires';
    const FALLBACK_LABEL = 'les plus récents';
    const FILTER_TEXTS   = ['plus pertinents', 'les plus récents', 'tous les commentaires'];
    const MAX_RETRIES    = 3;

    // Find the comment sort/filter button (aria-haspopup="menu")
    function findFilterBtn() {
      const candidates = document.querySelectorAll('[role="button"][aria-haspopup="menu"]');
      for (const el of candidates) {
        const t = norm(el.getAttribute('aria-label') || el.innerText || el.textContent || '');
        if (FILTER_TEXTS.some(f => t.includes(f))) return el;
      }
      return null;
    }

    // Read current filter button label
    function currentFilterText(btn) {
      return norm(btn.getAttribute('aria-label') || btn.innerText || btn.textContent || '');
    }

    // Poll document for role="menuitem" elements appearing after the click.
    // This is the reliable signal that the menu portal is rendered —
    // aria-expanded stays false on this button regardless of menu state.
    async function waitForMenuOption(labelToFind) {
      const deadline = Date.now() + 3000;
      while (Date.now() < deadline) {
        const items = document.querySelectorAll('[role="menuitem"]');
        for (const el of items) {
          const t = norm(el.innerText || el.textContent || '');
          if (t.startsWith(labelToFind)) return el;
        }
        await sleep(80);
      }
      return null;
    }

    for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
      if (S.cancelled) return;

      const btn = findFilterBtn();
      if (!btn) {
        log('Filtre introuvable (tentative ' + attempt + '/' + MAX_RETRIES + ')', 'warn');
        await sleep(800);
        continue;
      }

      const current = currentFilterText(btn);
      if (current.includes(TARGET_LABEL)) {
        log('Filtre déjà sur "Tous les commentaires" ✓', 'ok');
        return;
      }

      log('Filtre actuel: "' + current + '" — clic pour ouvrir le menu…');

      // Click the filter button — menu appears as a body-level portal
      btn.click();

      // Step 2: wait for role="menuitem" to appear in document (not aria-expanded)
      let option = await waitForMenuOption(TARGET_LABEL);
      if (!option) {
        log('"Tous les commentaires" absent — fallback "Les plus récents"', 'warn');
        option = await waitForMenuOption(FALLBACK_LABEL);
      }

      if (!option) {
        log('Aucune option trouvée (tentative ' + attempt + '/' + MAX_RETRIES + ')', 'warn');
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', bubbles: true }));
        await sleep(400);
        continue;
      }

      log('Clic sur "' + norm(option.innerText || option.textContent || '').slice(0, 30) + '"…');
      option.click();

      // Step 3: wait for comment list to reload
      await waitForDOMSettle();

      // Step 4: verify the filter button now shows the right label
      const updated = findFilterBtn();
      if (updated && currentFilterText(updated).includes(TARGET_LABEL)) {
        log('Filtre "Tous les commentaires" actif ✓', 'ok');
        return;
      }

      // Also accept fallback as success
      if (updated && currentFilterText(updated).includes(FALLBACK_LABEL)) {
        log('Filtre "Les plus récents" actif (fallback) ✓', 'ok');
        return;
      }

      log('Vérification filtre échouée (tentative ' + attempt + '/' + MAX_RETRIES + ')', 'warn');
      await sleep(500);
    }

    log('Impossible de changer le filtre — continuation quand même', 'warn');
  }

  /* ══════════════════════════════════════════════════════════════════
     EXPAND LOOP — smart early-exit on scrollHeight plateau
  ══════════════════════════════════════════════════════════════════ */
  async function expandLoop() {
    const deadline = S.t0 + CFG.MAX_RUNTIME_MS;
    let stableRounds = 0;
    const scrollHHistory = []; // track scrollHeight each stable round for early-exit

    while (Date.now() < deadline) {
      if (S.cancelled) return;
      ensureScroller();

      const sweepClicks = await sweepDown();
      const fullClicks  = await fullPageScan();
      const clicked = sweepClicks + fullClicks;
      S.nClicks += clicked;

      if (fullClicks > 0) log('Full-scan: +' + fullClicks + ' supplémentaires', 'ok');

      if (clicked > 0) {
        stableRounds = 0;
        scrollHHistory.length = 0;
        log('Round: ' + clicked + ' clics.', 'ok');
        prog(10 + Math.min(75, S.nClicks / 2));
      } else {
        // Record scrollH BEFORE the wait, and AFTER, to detect FB lazy-load
        const shBefore = scrollHeight();
        log('0 clics — attente (' + Math.round(CFG.BOTTOM_EXTRA_MS / 1000) + 's)…');

        // Scroll to bottom to re-trigger FB lazy-load, then wait
        scrollTo(shBefore);
        await sleep(500);
        scrollBy(CFG.SCROLL_STEP_PX);
        await sleep(CFG.BOTTOM_EXTRA_MS);

        const shAfter = scrollHeight();
        scrollHHistory.push(shAfter);

        log('scrollH: ' + shBefore + ' → ' + shAfter +
          (shAfter > shBefore ? ' (+' + (shAfter - shBefore) + ' FB a chargé plus)' : ' (stable)'));

        // Only count as a truly stable round if scrollH didn't grow during the wait.
        // If FB loaded more content (shAfter > shBefore), reset counter and sweep again.
        if (shAfter > shBefore) {
          stableRounds = 0;
          log('Nouveau contenu détecté — re-sweep…', 'ok');
          continue; // go back to sweep immediately
        }

        stableRounds++;
        log('Stable ' + stableRounds + '/' + CFG.STABLE_ROUNDS +
          ' scrollH=' + shAfter + ' floor=' + adaptiveFloor() + 'ms');

        if (stableRounds >= CFG.STABLE_ROUNDS) {
          log('Tous les commentaires sont ouverts.', 'ok');
          break;
        }
      }

      if (S.nClicks >= CFG.MAX_CLICKS) { log('Limite de clics.', 'warn'); break; }
    }

    if (Date.now() >= S.t0 + CFG.MAX_RUNTIME_MS) log('Temps limite.', 'warn');
    scrollTo(0); await sleep(300);
  }

  /* ── Sweep viewport top→bottom ─────────────────────────────────────── */
  async function sweepDown() {
    let total = 0;
    while (true) {
      if (S.cancelled) return total;
      let local;
      do {
        local = await clickVisible();
        if (local > 0) { total += local; await waitForDOMSettle(); }
      } while (local > 0 && !S.cancelled);
      await sleep(CFG.DWELL_MS);
      const prev = scrollTop();
      scrollBy(CFG.SCROLL_STEP_PX);
      await sleep(80);
      if (scrollTop() === prev) break;
    }
    await sleep(CFG.DWELL_MS);
    const last = await clickVisible();
    if (last > 0) { total += last; await waitForDOMSettle(); }
    return total;
  }

  /* ── Full-page scan — no scrollIntoView, direct click ──────────────── */
  async function fullPageScan() {
    let total = 0;
    const root = S.scroller || document;

    while (true) {
      if (S.cancelled) return total;
      const all = root.querySelectorAll('div[role="button"],span[role="button"],a[role="button"],button');
      const unclicked = [];
      for (const el of all) {
        const label = (el.getAttribute('aria-label') || el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120);
        if (!label || isDenied(label) || !matchesTarget(label)) continue;
        const fp = fingerprint(el);
        if (S.clickedFps.has(fp)) continue;
        unclicked.push({ el, label, fp });
      }
      if (unclicked.length === 0) break;

      log('Full-scan: ' + unclicked.length + ' non-cliqué(s)', 'ok');
      for (const { el, label, fp } of unclicked) {
        if (S.cancelled) return total;
        S.clickedFps.add(fp);
        log('  [full] → "' + label.slice(0, 60) + '"', 'ok');
        try { el.click(); total++; await waitForDOMSettle(); } catch (_) {}
      }
    }
    return total;
  }

  /* ── Click visible in-viewport buttons ─────────────────────────────── */
  async function clickVisible() {
    const root = S.scroller || document;
    const all = root.querySelectorAll('div[role="button"],span[role="button"],a[role="button"],button');
    const toClick = [];
    for (const el of all) {
      if (!isInView(el)) continue;
      const label = (el.getAttribute('aria-label') || el.innerText || el.textContent || '').replace(/\s+/g, ' ').trim().slice(0, 120);
      if (!label || isDenied(label) || !matchesTarget(label)) continue;
      const fp = fingerprint(el);
      if (S.clickedFps.has(fp)) continue;
      S.clickedFps.add(fp);
      log('  → "' + label.slice(0, 60) + '"  y' + fp.split('||y')[1], 'ok');
      toClick.push(el);
    }
    let clicked = 0;
    for (const el of toClick) {
      if (S.cancelled) break;
      try { el.click(); clicked++; await waitForDOMSettle(); } catch (_) {}
    }
    return clicked;
  }

  /* ── SAVE HTML ──────────────────────────────────────────────────────── */
  /* ── SAVE: MHTML first (.mht), HTML fallback ──────────────────────── */
  async function savePage() {
    // Step 1: scroll to top so capture starts from beginning
    scrollTo(0);
    await sleep(500);
    await waitForDOMSettle();

    // Step 2: hide panel so it doesn't appear in saved file
    const panel = g('fbps-panel');
    if (panel) panel.style.display = 'none';

    log('Tentative MHTML (.mht)…');
    let mhtmlOk = false;

    try {
      const result = await new Promise((resolve, reject) => {
        const timeout = setTimeout(
          () => reject(new Error('timeout 60s')),
          60000
        );
        chrome.runtime.sendMessage({ action: 'saveMHTML' }, res => {
          clearTimeout(timeout);
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
            return;
          }
          if (res && res.error) { reject(new Error(res.error)); return; }
          resolve(res);
        });
      });
      log('MHT sauvegardé ✓ (downloadId=' + result.downloadId + ')', 'ok');
      mhtmlOk = true;
    } catch (err) {
      log('MHTML échoué (' + err.message + ') — fallback HTML…', 'warn');
    }

    // Step 3: restore panel visibility
    if (panel) panel.style.display = '';

    // Step 4: HTML fallback if MHTML failed
    if (!mhtmlOk) await saveHTML();
  }

  async function saveHTML() {
    log('Clonage page HTML…');
    const clone = document.documentElement.cloneNode(true);
    clone.querySelector('#fbps-panel')?.remove();
    clone.querySelectorAll('script,noscript').forEach(e => e.remove());
    const parts = [];
    for (const sheet of document.styleSheets) {
      try { for (const r of (sheet.cssRules || [])) { try { parts.push(r.cssText); } catch (_) {} } } catch (_) {}
    }
    let head = clone.querySelector('head');
    if (!head) { head = document.createElement('head'); clone.insertBefore(head, clone.firstChild); }
    if (!head.querySelector('meta[charset]')) { const m = document.createElement('meta'); m.setAttribute('charset', 'UTF-8'); head.insertBefore(m, head.firstChild); }
    const st = document.createElement('style'); st.textContent = parts.join('\n'); head.appendChild(st);
    const html = '<!DOCTYPE html>\n' + clone.outerHTML;
    const ts = new Date().toISOString().slice(0, 19).replace(/[T:]/g, '-');
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = Object.assign(document.createElement('a'), { href: url, download: 'facebook_post_' + ts + '.html' });
    a.style.display = 'none'; document.body.appendChild(a); a.click();
    setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 4000);
    log('HTML sauvegardé ✓', 'ok');
  }

  buildPanel();
  log('Prêt — cliquez "Save Full Post" pour commencer.', 'ok');

})();
